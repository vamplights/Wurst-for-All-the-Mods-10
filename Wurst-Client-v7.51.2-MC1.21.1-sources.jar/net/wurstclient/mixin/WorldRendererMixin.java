/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_4184;
import net.minecraft.class_761;
import net.wurstclient.WurstClient;

@Mixin(class_761.class)
public class WorldRendererMixin
{
	@Inject(at = @At("HEAD"),
		method = "doesMobEffectBlockSky(Lnet/minecraft/client/Camera;)Z",
		cancellable = true)
	private void onHasBlindnessOrDarkness(class_4184 camera,
		CallbackInfoReturnable<Boolean> ci)
	{
		if(WurstClient.INSTANCE.getHax().antiBlindHack.isEnabled())
			ci.setReturnValue(false);
	}
}
