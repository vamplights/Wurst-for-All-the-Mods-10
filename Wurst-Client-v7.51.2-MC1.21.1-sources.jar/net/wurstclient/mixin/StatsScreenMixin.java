/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_447;
import net.minecraft.class_8021;
import net.minecraft.class_8667;
import net.wurstclient.WurstClient;

@Mixin(class_447.class)
public class StatsScreenMixin
{
	@WrapOperation(at = @At(value = "INVOKE",
		target = "Lnet/minecraft/client/gui/layouts/LinearLayout;addChild(Lnet/minecraft/client/gui/layouts/LayoutElement;)Lnet/minecraft/client/gui/layouts/LayoutElement;",
		ordinal = 4), method = "initButtons()V")
	private <T extends class_8021> T onCreateDoneButton(class_8667 layout,
		T doneWidget, Operation<T> original)
	{
		if(!(doneWidget instanceof class_4185 doneButton))
			throw new IllegalStateException(
				"The done button in the statistics screen somehow isn't a button");
		
		if(WurstClient.INSTANCE.getOtfs().disableOtf.shouldHideEnableButton())
			return original.call(layout, doneButton);
		
		doneButton.method_25358(150);
		
		class_8667 subLayout =
			layout.method_52736(class_8667.method_52742()).method_52735(5);
		subLayout.method_52736(class_4185.method_46430(getButtonText(), this::toggleWurst)
			.method_46432(150).method_46431());
		return original.call(subLayout, doneButton);
	}
	
	@Unique
	private void toggleWurst(class_4185 button)
	{
		WurstClient wurst = WurstClient.INSTANCE;
		wurst.setEnabled(!wurst.isEnabled());
		button.method_25355(getButtonText());
	}
	
	@Unique
	private class_2561 getButtonText()
	{
		WurstClient wurst = WurstClient.INSTANCE;
		String text = (wurst.isEnabled() ? "Disable" : "Enable") + " Wurst";
		return class_2561.method_43470(text);
	}
}
