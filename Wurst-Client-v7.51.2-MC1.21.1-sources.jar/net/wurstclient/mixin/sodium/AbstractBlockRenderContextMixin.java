/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.sodium;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.ShouldDrawSideListener.ShouldDrawSideEvent;

/**
 * Last updated for <a href=
 * "https://github.com/CaffeineMC/sodium/tree/320aad8b70bf22254452872c7e9443c8b55efbc5">Sodium
 * 0.6.13+mc1.21.4</a>
 */
@Pseudo
@Mixin(targets = {
	"net.caffeinemc.mods.sodium.client.render.frapi.render.AbstractBlockRenderContext"})
public class AbstractBlockRenderContextMixin
{
	@Shadow
	protected class_2680 state;
	
	@Shadow
	protected class_2338 pos;
	
	/**
	 * Hides and shows blocks when using X-Ray with Sodium installed.
	 */
	@Inject(at = @At("HEAD"),
		method = "isFaceCulled(Lnet/minecraft/class_2350;)Z",
		cancellable = true,
		remap = false,
		require = 0)
	private void onIsFaceCulled(@Nullable class_2350 face,
		CallbackInfoReturnable<Boolean> cir)
	{
		ShouldDrawSideEvent event = new ShouldDrawSideEvent(state, pos);
		EventManager.fire(event);
		
		if(event.isRendered() != null)
			cir.setReturnValue(!event.isRendered());
	}
}
