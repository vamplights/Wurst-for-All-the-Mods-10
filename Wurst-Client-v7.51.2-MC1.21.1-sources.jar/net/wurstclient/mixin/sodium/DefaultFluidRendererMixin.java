/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.sodium;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.wurstclient.WurstClient;
import net.wurstclient.event.EventManager;
import net.wurstclient.events.ShouldDrawSideListener.ShouldDrawSideEvent;
import net.wurstclient.hacks.XRayHack;

@Pseudo
@Mixin(targets = {
	"net.caffeinemc.mods.sodium.client.render.chunk.compile.pipeline.DefaultFluidRenderer"},
	remap = false)
public class DefaultFluidRendererMixin
{
	@Unique
	private ThreadLocal<class_2338.class_2339> mutablePosForExposedCheck =
		ThreadLocal.withInitial(class_2338.class_2339::new);
	
	/**
	 * This mixin hides and shows fluids when using X-Ray with Sodium installed.
	 *
	 * <p>
	 * Works with Sodium >=0.6.0-beta.1 and <0.6.1.
	 */
	@Inject(at = @At("HEAD"),
		method = "isFluidOccluded(Lnet/minecraft/class_1920;IIILnet/minecraft/class_2350;Lnet/minecraft/class_2680;Lnet/minecraft/class_3611;)Z",
		cancellable = true,
		remap = false,
		require = 0)
	private void onIsFluidOccludedInSodium060(class_1920 world, int x,
		int y, int z, class_2350 dir, class_2680 state, class_3611 fluid,
		CallbackInfoReturnable<Boolean> cir)
	{
		class_2338.class_2339 pos = mutablePosForExposedCheck.get();
		pos.method_10103(x, y, z);
		ShouldDrawSideEvent event = new ShouldDrawSideEvent(state, null);
		EventManager.fire(event);
		
		if(event.isRendered() != null)
			cir.setReturnValue(!event.isRendered());
	}
	
	/**
	 * This mixin hides and shows fluids when using X-Ray with Sodium installed.
	 *
	 * <p>
	 * Works with Sodium >=0.6.1 and <0.6.13. Last tested with Sodium
	 * 0.6.5+mc1.21.1.
	 */
	@Inject(at = @At("HEAD"),
		method = "isFluidOccluded(Lnet/minecraft/class_1920;IIILnet/minecraft/class_2350;Lnet/minecraft/class_2680;Lnet/minecraft/class_3610;)Z",
		cancellable = true,
		require = 0)
	private void onIsFluidOccluded(class_1920 world, int x, int y,
		int z, class_2350 dir, class_2680 state, class_3610 fluid,
		CallbackInfoReturnable<Boolean> cir)
	{
		class_2338.class_2339 pos = mutablePosForExposedCheck.get();
		pos.method_10103(x, y, z);
		ShouldDrawSideEvent event = new ShouldDrawSideEvent(state, null);
		EventManager.fire(event);
		
		if(event.isRendered() != null)
			cir.setReturnValue(!event.isRendered());
	}
	
	/**
	 * Hides and shows fluids when using X-Ray with Sodium installed.
	 *
	 * <p>
	 * Works with Sodium >=0.6.13. Last updated for Sodium 0.6.13+mc1.21.4.
	 */
	@Inject(at = @At("HEAD"),
		method = "isFullBlockFluidOccluded(Lnet/minecraft/class_1920;Lnet/minecraft/class_2338;Lnet/minecraft/class_2350;Lnet/minecraft/class_2680;Lnet/minecraft/class_3610;)Z",
		cancellable = true,
		remap = false,
		require = 0)
	private void onIsFullBlockFluidOccluded(class_1920 world,
		class_2338 pos, class_2350 dir, class_2680 state, class_3610 fluid,
		CallbackInfoReturnable<Boolean> cir)
	{
		// Note: the null BlockPos is here to skip the "exposed only" check
		ShouldDrawSideEvent event = new ShouldDrawSideEvent(state, null);
		EventManager.fire(event);
		
		if(event.isRendered() != null)
			cir.setReturnValue(!event.isRendered());
	}
	
	/**
	 * Modifies opacity of fluids when using X-Ray with Sodium installed.
	 *
	 * <p>
	 * Works with Sodium >=0.6.13. Last updated for Sodium 0.6.13+mc1.21.4.
	 */
	@ModifyExpressionValue(at = @At(value = "INVOKE",
		target = "Lnet/caffeinemc/mods/sodium/api/util/ColorARGB;toABGR(I)I"),
		method = "updateQuad",
		remap = false,
		require = 0)
	private int onUpdateQuad(int original, @Local(argsOnly = true) class_2338 pos,
		@Local(argsOnly = true) class_3610 state)
	{
		XRayHack xray = WurstClient.INSTANCE.getHax().xRayHack;
		if(!xray.isOpacityMode()
			|| xray.isVisible(state.method_15759().method_26204(), pos))
			return original;
		
		return original & xray.getOpacityColorMask();
	}
}
