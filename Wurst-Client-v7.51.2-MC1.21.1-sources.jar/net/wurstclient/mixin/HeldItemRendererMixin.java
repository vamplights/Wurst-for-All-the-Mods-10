/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.wurstclient.WurstClient;

@Mixin(class_759.class)
public abstract class HeldItemRendererMixin
{
	@Inject(at = {@At(value = "INVOKE",
		target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;applyItemArmTransform(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/entity/HumanoidArm;F)V",
		ordinal = 4)}, method = "renderArmWithItem")
	private void onApplyEquipOffsetBlocking(class_742 player,
		float tickDelta, float pitch, class_1268 hand, float swingProgress,
		class_1799 item, float equipProgress, class_4587 matrices,
		class_4597 vertexConsumers, int light, CallbackInfo ci)
	{
		// lower shield when blocking
		if(item.method_7909() == class_1802.field_8255)
			WurstClient.INSTANCE.getHax().noShieldOverlayHack
				.adjustShieldPosition(matrices, true);
	}
	
	@Inject(at = {@At(value = "INVOKE",
		target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;applyItemArmAttackTransform(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/entity/HumanoidArm;F)V",
		ordinal = 1)}, method = "renderArmWithItem")
	private void onApplySwingOffsetNotBlocking(class_742 player,
		float tickDelta, float pitch, class_1268 hand, float swingProgress,
		class_1799 item, float equipProgress, class_4587 matrices,
		class_4597 vertexConsumers, int light, CallbackInfo ci)
	{
		// lower shield when not blocking
		if(item.method_7909() == class_1802.field_8255)
			WurstClient.INSTANCE.getHax().noShieldOverlayHack
				.adjustShieldPosition(matrices, false);
	}
}
