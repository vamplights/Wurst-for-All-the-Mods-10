/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks.autofarm.plants;

import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5803;
import net.wurstclient.WurstClient;
import net.wurstclient.hacks.autofarm.AutoFarmPlantType;
import net.wurstclient.settings.PlantTypeSetting;
import net.wurstclient.util.BlockUtils;

public final class GlowBerryPlantType extends AutoFarmPlantType
{
	@Override
	public final boolean isReplantingSpot(class_2338 pos, class_2680 state)
	{
		return state.method_26204() instanceof class_5803 && hasPlantingSurface(pos);
	}
	
	@Override
	public final boolean hasPlantingSurface(class_2338 pos)
	{
		class_2680 ceiling = BlockUtils.getState(pos.method_10084());
		return !(ceiling.method_26204() instanceof class_5803)
			&& ceiling.method_26206(WurstClient.MC.field_1687, pos, class_2350.field_11033);
	}
	
	@Override
	public class_1792 getSeedItem()
	{
		return class_1802.field_28659;
	}
	
	@Override
	public boolean shouldHarvestByInteracting(class_2338 pos, class_2680 state)
	{
		// Right-click-harvest the top-most part so we don't have to replant it.
		return state.method_26204() instanceof class_5803
			&& class_5803.method_33618(state) && isReplantingSpot(pos, state);
	}
	
	@Override
	public boolean shouldHarvestByMining(class_2338 pos, class_2680 state)
	{
		// Left-click-harvest any other part so it can grow more berries.
		return state.method_26204() instanceof class_5803
			&& !isReplantingSpot(pos, state);
	}
	
	@Override
	protected PlantTypeSetting createSetting()
	{
		return new PlantTypeSetting("Glow Berries", class_1802.field_28659, true,
			true);
	}
}
