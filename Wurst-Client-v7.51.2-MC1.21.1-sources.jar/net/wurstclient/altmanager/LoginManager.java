/*
 * Copyright (c) 2014-2025 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.altmanager;

import java.util.Optional;
import net.minecraft.class_320;
import net.minecraft.class_4844;
import net.wurstclient.WurstClient;

public enum LoginManager
{
	;
	
	public static void changeCrackedName(String newName)
	{
		class_320 session =
			new class_320(newName, class_4844.method_43344(newName), "",
				Optional.empty(), Optional.empty(), class_320.class_321.field_1988);
		
		WurstClient.IMC.setWurstSession(session);
	}
}
